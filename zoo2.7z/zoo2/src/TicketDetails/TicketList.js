import React from "react";

const TicketList = () => {
  const ticketVal = localStorage.getItem("ticketType");
  console.log("ticketVal1", ticketVal);
  const userName = JSON.parse(localStorage.getItem("UserValues"));
  console.log("userName1", userName.name);
  return (
    <div>
      <h1>Ticket List</h1>
      <table>
        <tr>
          <th>Ticket No.</th>
          <th>Ticket Type</th>
          <th>Quantity</th>
          <th>Active</th>

          <th>Assigned</th>
          <th>Name</th>
        </tr>
        <tr>
          <td>
            {ticketVal === "premium" ? (
              <div style={{ backgroundColor: "orange" }}>
                PRE-{Math.floor(Math.random() * 10000) + 1}
              </div>
            ) : ticketVal === "vip" ? (
              <div style={{ backgroundColor: "pink" }}>
                VIP-{Math.floor(Math.random() * 10000) + 1}
              </div>
            ) : (
              <div style={{ backgroundColor: "yellow" }}>
                GEN-{Math.floor(Math.random() * 10000) + 1}
              </div>
            )}
          </td>
          <td>{ticketVal}</td>
          <td>Germany</td>
        </tr>
      </table>
    </div>
  );
};

export default TicketList;
