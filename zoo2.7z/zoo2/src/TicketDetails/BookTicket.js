import React, { useState } from "react";
import { useSelector, useDispatch } from "react-redux";
import { addTodo, deleteTodo, removeTodo } from "../actions";
// import { FontAwesomeIcon } from "font-awesome";
import { incNumber, decNumber } from "../actions";

const BookTicket = () => {
  const [inputData, setInputData] = useState("");
  const [inc, setInc] = useState(0);
  const myState = useSelector((state) => state.changeTheNumber);

  const list = useSelector((state) => state.todoReducers.list);
  const dispatch = useDispatch();
  const handleChange = (event) => {
    localStorage.setItem("ticketType", event.target.value);
  };
  const ticketVal = localStorage.getItem("ticketType");
  console.log("ticketVal", ticketVal);
  const userName = JSON.parse(localStorage.getItem("UserValues"));
  console.log("userName", userName.name);

  return (
    <>
      <div className="main-div">
        <div className="child-div">
          <figure>
            <figcaption>Select Your Ticket</figcaption>
          </figure>
          <div className="addItems">
            {/* <input
              type="text"
              placeholder="Add items.."
              value={inputData}
              onChange={(event) => setInputData(event.target.value)}
            /> */}
            <select
              name="cars"
              id="cars"
              onChange={handleChange}
              value={ticketVal}
            >
              <option value="general">general</option>
              <option value="premium">premium</option>
              <option value="vip">VIP</option>
            </select>
            <a
              className="quantity-minus"
              onClick={() => dispatch(setInc(inc - 1))}
            >
              <span> - </span>
            </a>
            <input
              name="quantity"
              type="text"
              className="quantity-input"
              value={inc}
            />
            <a
              className="quantity-plus"
              onClick={() => dispatch(setInc(inc + 1))}
            >
              <span> + </span>
            </a>
            {/* <FontAwesomeIcon icon="fa-solid fa-plus" /> */}
            <button
              className="fa-solid fa-plus"
              onClick={() =>
                // localStorage.setItem(
                //   "table",
                //   JSON.stringify(dispatch(addTodo(inputData)), setInputData(""))
                // )
                localStorage.setItem(
                  "items",
                  JSON.stringify(dispatch(addTodo(inputData)))
                )
              }
            >
              Add
            </button>
          </div>

          <div className="showItems">
            {list.map((elem) => {
              return (
                <div className="eachItem" key={elem.id}>
                  <table>
                    <tr>
                      <th>Ticket No.</th>
                      <th>Ticket Type</th>
                      <th> Quantity</th>

                      <th>Active</th>
                      <th>Assigned</th>
                      <th>Name</th>
                    </tr>
                    <tr>
                      <td>
                        {ticketVal === "premium" ? (
                          <div style={{ backgroundColor: "orange" }}>
                            PRE-{Math.floor(Math.random() * 10000) + 1}
                          </div>
                        ) : ticketVal === "vip" ? (
                          <div style={{ backgroundColor: "pink" }}>
                            VIP-{Math.floor(Math.random() * 10000) + 1}
                          </div>
                        ) : (
                          <div style={{ backgroundColor: "yellow" }}>
                            GEN-{Math.floor(Math.random() * 10000) + 1}
                          </div>
                        )}
                      </td>
                      {/* <td>{ticketVal}</td> */}
                      <td>{ticketVal}</td>
                      <td>{inc}</td>
                      <td>True</td>
                      <td>False</td>
                      <td>{userName[0].name}</td>
                    </tr>
                  </table>
                  <div className="todo-btn">
                    <i
                      className="far fa-trash-alt add-btn"
                      title="delete item"
                      onClick={() => dispatch(deleteTodo(elem.id))}
                    />
                  </div>
                </div>
              );
            })}
          </div>

          <div className="showItems">
            <button
              className="btn effect04"
              data-sm-link-text="removeAll"
              onClick={() => dispatch(removeTodo())}
            >
              <span>checkList</span>
            </button>
          </div>
        </div>
      </div>
    </>
  );
};
export default BookTicket;
